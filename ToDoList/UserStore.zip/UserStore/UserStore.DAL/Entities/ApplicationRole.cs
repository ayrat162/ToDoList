﻿using Microsoft.AspNet.Identity.EntityFramework;

namespace UserStore.DAL.Entities
{
    public class ApplicationRole : IdentityRole
    {
    }
}
